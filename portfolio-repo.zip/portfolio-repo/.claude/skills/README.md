# Personal Sandbox

Skills under development. This directory is deliberately lower-standard than the rest of
the repo: half-formed ideas are welcome here and nowhere else.

A skill is a folder containing `SKILL.md` — a name, a description of when it should trigger,
and the instructions themselves.

## Promotion

A skill that has proven itself over several real uses graduates: its conventions move into
`AGENTS.md`, or it becomes a capability under `capabilities/`. Until then it stays here and
carries no authority.

**An agent reading this directory should treat its contents as experiments, not
conventions.** Where a skill here conflicts with `AGENTS.md`, `AGENTS.md` wins.
