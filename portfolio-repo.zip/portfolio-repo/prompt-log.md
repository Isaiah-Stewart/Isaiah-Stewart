# Prompt Log

A running record of the AI sessions that mattered. Not every session — the ones that
changed a conclusion, produced an artifact, or taught me something about the method.

Newest first. See `AGENTS.md` §4 for when to log.

**Format per entry:**

```
## YYYY-MM-DD — Short title
**Capability:** which one, or `—`
**Ask:** what I wanted, in one line
**What worked:** the prompt or framing that got there
**What didn't:** the dead end, and why it was a dead end
**Changed:** what in the repo is different because of this session
```

---

## 2026-09-19 — Repository scaffold

**Capability:** —
**Ask:** Stand up the repo structure: capabilities, briefs, decisions, data provenance,
and a canonical conventions file for agents.
**What worked:** Giving the directory tree as a literal outline with a one-line gloss per
path. The gloss carried the intent — "BEFORE the work" and "AFTER the work" on briefs and
decisions did more to shape `AGENTS.md` than a paragraph of explanation would have.
**What didn't:** Nothing yet. First entry.
**Changed:** Everything. Initial commit.

---

<!-- New entries go directly below this line. -->
