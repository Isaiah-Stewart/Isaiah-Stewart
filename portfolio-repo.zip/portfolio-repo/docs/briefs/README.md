# Briefs

Written **before** the work. A brief is a commitment device: it fixes the question and the
hypothesis while I am still ignorant of the answer, so I cannot later claim to have
predicted whatever I found.

One file per question: `YYYY-MM-DD-short-slug.md`. Copy `_TEMPLATE.md`.

A brief is finished when someone else could run the analysis from it and know what would
count as a negative result.

**Briefs are not revised to match the outcome.** When the work is done, add a closing note
recording what actually happened. If the hypothesis was wrong, it stays on the page. The
falsified briefs are the ones that make the rest credible.
