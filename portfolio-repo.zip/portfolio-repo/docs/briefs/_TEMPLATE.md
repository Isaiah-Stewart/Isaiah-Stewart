# Brief — <title>

**Date:** YYYY-MM-DD
**Capability:** <capabilities/…> or `—`
**Status:** open · in progress · closed
**Decision this serves:** <docs/decisions/YYYY-MM-DD-same-slug.md> when it exists

## Question

One sentence. A question, ending in a question mark. If it takes two sentences, there are
two questions — split them.

## Why it matters

What changes based on the answer. If nothing changes either way, stop here and do something
else.

## Hypothesis

What I expect to find, and roughly how strongly. State a number if one is implied — "costs
rise past ~40k units" beats "costs rise eventually."

## What would falsify it

The observation that would make me abandon the hypothesis. Be specific enough that I cannot
wriggle out later. A hypothesis with no falsifier is not a hypothesis.

## Method

The approach, the model or capability used, and the volume of work expected.

## Inputs needed

| Input | Source | Have it? |
|---|---|---|
|  |  |  |

Anything not yet in `data/` with a `SOURCES.md` entry is a blocker, not a detail.

## Out of scope

What this deliberately does not address. Prevents the question from growing while the work
is underway.

---

## Closing note

*Filled in after the work. Do not edit the sections above.*

**What actually happened:**
**Hypothesis held / failed:**
**What I would do differently:**
