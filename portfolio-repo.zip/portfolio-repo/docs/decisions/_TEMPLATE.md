# Decision — <title>

**Date:** YYYY-MM-DD
**Brief:** <docs/briefs/YYYY-MM-DD-same-slug.md>
**Capability:** <capabilities/…> or `—`
**Status:** proposed · accepted · superseded by <…>

## Recommendation

The recommendation, first, in one or two sentences. No preamble. If the analysis was
inconclusive, that is the first line.

## Confidence

High · Medium · Low — and the reason. What would raise it.

## What the analysis found

The finding. Lead with the number that drives the recommendation.

| Claim | Evidence |
|---|---|
|  | `analysis/figures/NN-slug.png` |
|  | `data/source-descriptor-YYYY-MM-DD.csv` |

## Why not the alternatives

The options considered and rejected, and what would have to be true for each to win. An
option with no stated condition for winning was never seriously considered.

## What this assumes

The assumptions the recommendation rests on, and which one breaking would change it most.

## What would reverse this

The observation that should trigger revisiting. Name it now, while it is cheap to admit.
