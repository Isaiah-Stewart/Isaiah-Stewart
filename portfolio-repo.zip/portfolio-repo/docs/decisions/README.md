# Decisions

Written **after** the work. A decision states the recommendation and shows its evidence.

One file per decision: `YYYY-MM-DD-short-slug.md`, carrying the **same slug as its brief**,
so the pair is obvious in a directory listing. Copy `_TEMPLATE.md`.

Every claim links to the figure or data file supporting it. A recommendation with no
traceable evidence does not ship — see `AGENTS.md` §3.

These are durable. A decision that was later reversed is not deleted; it gets a superseded
note at the top pointing to the decision that replaced it, and the reason. The trail of
reversals is part of the record.
