See [AGENTS.md](./AGENTS.md) — it is canonical. This file exists only to point there.
