# Analysis

The findings, and the charts they refer to.

`figures/` holds the charts. Naming: `NN-short-slug.png`, where `NN` orders them within a
capability so a reader can follow the argument in sequence.

## Rules

- **A figure is cited or it is deleted.** Every chart here is referenced by a file in
  `docs/decisions/`. Orphaned charts are noise.
- **A figure carries its own units and source.** Axis labels with units, and a caption
  naming the data file behind it. Charts get pasted into decks and separated from this
  repo; it must survive the trip.
- **The generating code lives beside the output** where a script produced the chart, so the
  figure can be regenerated when inputs change.
