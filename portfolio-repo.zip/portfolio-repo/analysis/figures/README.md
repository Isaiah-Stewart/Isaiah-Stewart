# Figures

`NN-short-slug.png`. `NN` orders the figures within a capability's argument.

Each figure needs axis labels with units and a caption naming its data source. See
`../README.md`.
