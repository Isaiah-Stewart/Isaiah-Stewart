# AGENTS.md

Conventions for any AI agent working in this repository. This file is canonical.
`CLAUDE.md` points here. If you are an agent and you read only one file, read this one.

---

## 1. What this repository is

A working portfolio. It holds **capabilities** (things I can do, demonstrated), the
**reasoning** behind each piece of work, and the **record** of how AI was used to get there.

It is not a code library and not a scratchpad. Every file here is either evidence of a
capability or the reasoning that produced it.

---

## 2. Map

| Path | Holds | Written |
|---|---|---|
| `RESUME.md` | The resume itself | By me |
| `AGENTS.md` | This file. Canonical AI conventions | By me |
| `CLAUDE.md` | One line, pointing here | By me |
| `prompt-log.md` | Running record of AI sessions that mattered | Me + agent |
| `.claude/skills/` | Personal sandbox. Experiments, not yet conventions | Either |
| `capabilities/` | One folder per capability | Either |
| `docs/briefs/` | **Before** the work: scope + hypothesis | By me |
| `docs/decisions/` | **After** the work: the recommendation | Either |
| `data/` | Sourced inputs, with provenance | Either |
| `analysis/figures/` | Findings, and the charts they refer to | Either |

---

## 3. The workflow

Work moves in one direction. Do not skip a stage.

```
docs/briefs/       →  data/        →  analysis/    →  docs/decisions/
scope + hypothesis    sourced input   the finding     the recommendation
```

**A brief exists before analysis begins.** If asked to analyze something and there is no
brief in `docs/briefs/`, write the brief first and get it confirmed. A brief states the
question, the hypothesis, what would falsify it, and what decision the answer serves.

**A decision cites its analysis.** Every file in `docs/decisions/` links to the figures and
data that support it. A recommendation with no traceable evidence does not ship.

**A hypothesis that was wrong stays in the repo.** Do not quietly delete a brief whose
hypothesis failed. Update it with what actually happened. The falsified ones are the most
credible thing here.

---

## 4. Rules for agents

**Provenance is not optional.** Every file in `data/` needs a matching entry in
`data/SOURCES.md`: where it came from, when it was retrieved, the URL or system of record,
and any transformation applied. Data with no provenance entry is treated as untrusted and
must not support a decision.

**Never invent a number.** If a figure is unknown, write `TK` and flag it. A plausible
placeholder that survives into a decision file is the worst failure mode in this repo.
Estimates are allowed when labeled as estimates, with the method stated.

**Cite inside the artifact.** Assumptions live next to the number they drive — a cell
comment, a footnote, a line under the table. Not in a separate document the reader will
never open.

**Formulas, not pasted results.** Spreadsheets must recalculate when inputs change. No
hardcoded values where a formula belongs.

**Follow the spec literally.** Each capability has a `spec.md`. Exact tab names, exact
column headers, exact method. An elegant redesign that answers a different question fails.

**Ask before restructuring.** Adding a file inside the existing structure: go ahead.
Changing the structure itself, renaming directories, or altering this file: ask first.

**Log the session.** Any AI session that changed a conclusion, produced an artifact, or
taught me something goes in `prompt-log.md`. Routine edits do not.

---

## 5. Naming

```
docs/briefs/YYYY-MM-DD-short-slug.md
docs/decisions/YYYY-MM-DD-short-slug.md      # slug matches its brief
data/source-descriptor-YYYY-MM-DD.csv
analysis/figures/NN-short-slug.png           # NN orders them within a capability
capabilities/<capability-name>/              # lowercase, hyphenated
```

Dates are ISO 8601. Slugs are lowercase and hyphenated. A decision carries the same slug as
the brief it answers, so the pair is obvious in a directory listing.

---

## 6. Never commit

Enforced by `.gitignore`, but the rule is yours to hold, not the tool's:

- Credentials, API keys, `.env` files, tokens
- Personally identifying information in any form
- Licensed or proprietary data that is not mine to redistribute
- Raw exports containing anything not cleared for publication
- Large binaries. If an input is too large, commit the retrieval script and the provenance
  entry instead of the file

When in doubt, leave it out and note it in `data/SOURCES.md` as held externally.

---

## 7. Style

Plain sentences. Short paragraphs. No bolded conclusions that the evidence does not carry.

Write for a reader who is skeptical, competent, and short on time. Lead with the finding,
then the method, then the caveats. If the analysis is inconclusive, say so in the first
line — do not bury it under a summary that implies more confidence than exists.
