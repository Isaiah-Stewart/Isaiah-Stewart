# Isaiah Stewart

<!-- Replace every TK. An unfilled TK is visible to anyone reading this repo. -->

TK city · TK email · TK linkedin · TK github

---

## Summary

Two or three sentences. What I do, the domain I do it in, and the kind of problem I am
useful on. Written for someone deciding in fifteen seconds whether to keep reading.

Skip the adjectives. "I build volume and pricing models that hold up under scrutiny" beats
"results-driven analytical professional."

---

## Capabilities

Each links to its folder. A capability listed here without a folder behind it is a claim;
one with a folder is evidence.

| Capability | What it answers | Evidence |
|---|---|---|
| Marginal analysis | At what volume does the next unit stop paying for itself? | [`capabilities/marginal-analysis/`](capabilities/marginal-analysis/) |
| TK | TK | TK |

---

## Experience

### TK Title — TK Organization
*TK Month YYYY – TK Month YYYY · TK Location*

- Lead with the outcome, then the method. A bullet that names no result is a job
  description, not an accomplishment.
- Quantify where the number is real and yours to share. Where it is not, describe the scale
  qualitatively rather than inventing a figure — see `AGENTS.md` §4.
- Three to five bullets. The fourth-best thing dilutes the best thing.

### TK Title — TK Organization
*TK Month YYYY – TK Month YYYY · TK Location*

- TK

---

## Education

**TK Degree, TK Field** — TK Institution, TK Year
TK relevant coursework, honors, or thesis, if it earns the line.

---

## Tools

Grouped, not listed flat. Name the ones I would be comfortable being tested on.

**Analysis:** TK
**Modeling:** TK
**Engineering:** TK

---

## How this repository works

This is a working portfolio, not just a resume. `capabilities/` holds demonstrated work.
`docs/briefs/` holds the question and hypothesis I committed to *before* each piece of
analysis; `docs/decisions/` holds the recommendation that came out of it. The briefs whose
hypotheses failed are still there.

`AGENTS.md` documents how I work with AI tools, and `prompt-log.md` records the sessions
that changed a conclusion.
