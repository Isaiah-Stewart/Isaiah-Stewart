# Provenance Ledger

Every file in `data/` appears here. Newest first.

**Required per entry:** filename · source · retrieval date · URL or system of record ·
transformations applied · license or usage terms · known limitations.

---

## `_TEMPLATE`

| Field | Value |
|---|---|
| **File** | `source-descriptor-YYYY-MM-DD.csv` |
| **Source** | Publisher or system of record |
| **Retrieved** | YYYY-MM-DD |
| **URL / locator** | https://… or the query used |
| **Derived from** | Parent file, or `—` if primary |
| **Transformations** | What was changed, and by what script. `none` if untouched |
| **License / terms** | Redistribution terms. If unclear, say so and do not commit |
| **Limitations** | Coverage gaps, known errors, why a reader should be careful |

---

<!-- New entries go directly below this line. -->
