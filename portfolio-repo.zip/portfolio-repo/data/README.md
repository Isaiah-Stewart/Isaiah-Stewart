# Data

Sourced inputs. Every file here has an entry in `SOURCES.md` — no exceptions.

Data with no provenance entry is treated as untrusted and must not support a decision
(`AGENTS.md` §4).

## Conventions

- Naming: `source-descriptor-YYYY-MM-DD.ext`, where the date is **retrieval date**, not
  the date of the underlying period.
- Raw stays raw. Never edit a retrieved file in place. Transformations produce a new file
  with its own `SOURCES.md` entry naming its parent.
- `data/raw/` and `data/private/` are gitignored. Files there are held locally; record them
  in `SOURCES.md` as held externally so the gap is visible rather than silent.
- Too large to commit? Commit the retrieval script and the provenance entry instead.
