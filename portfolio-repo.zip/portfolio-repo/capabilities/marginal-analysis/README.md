# Marginal Analysis

**The question it answers:** at what volume does the next unit stop paying for itself?

Most volume decisions are argued on averages — average cost per unit, average margin,
blended contribution. Averages hide the turning point. The unit that matters is the *next*
one, and its economics differ from the average whenever cost or price moves with scale.

This capability builds the marginal picture: marginal revenue against marginal cost across
a volume range, and the point where they cross.

## Contents

| File | What it is |
|---|---|
| `spec.md` | The method, inputs, outputs, and assumptions. Read before touching the model |
| `model.xlsx` | The working model. Blue cells are inputs; everything else is formula |

## Using the model

Open `model.xlsx`, go to the **Assumptions** tab, and edit the blue cells only. The
**Model** tab recalculates: the profit-maximizing volume and the price at that volume
appear in the summary block below the grid.

Read the `MR − MC` column, not the profit column. Profit tells you where you are; `MR − MC`
tells you which direction to move. While it is positive, the next unit adds profit. The
optimum is the last row before it turns negative.

## When this is the wrong tool

- **Capacity is hard-constrained.** If volume cannot move, the marginal question is moot —
  the decision is about the constraint, not the unit.
- **Costs are genuinely linear and price is fixed.** Then marginal equals average and this
  adds nothing over a contribution-margin calculation.
- **The volume range is wide enough to change the business.** This model assumes the cost
  and demand structure holds across the range. Cross a step-function in capacity and the
  assumption breaks. Note the break and model the segments separately.
