# Spec — Marginal Analysis

Authoritative. The model implements this document. Where they disagree, this wins and the
model is wrong.

## Inputs

All live on the **Assumptions** tab, blue text, yellow fill.

| Cell | Name | Unit | Meaning |
|---|---|---|---|
| `B4` | Choke price (a) | $/unit | Price at which demand reaches zero |
| `B5` | Price slope (b) | $/unit² | Price decline per additional unit sold |
| `B6` | Fixed cost | $ | Cost incurred at zero volume |
| `B7` | Variable cost (c) | $/unit | Cost of a unit, independent of volume |
| `B8` | Cost convexity (d) | $/unit² | Rate at which unit cost rises with volume |
| `B9` | Step size | units | Volume increment between grid rows |

## Method

Linear inverse demand, quadratic cost:

```
Price(Q)    = a − bQ
Revenue(Q)  = Q · Price(Q)
TotalCost(Q)= FixedCost + cQ + dQ²
Profit(Q)   = Revenue(Q) − TotalCost(Q)

MR(Q) = ΔRevenue   / ΔQ      discrete, across one grid step
MC(Q) = ΔTotalCost / ΔQ      discrete, across one grid step
```

Marginal figures are **discrete differences across a grid step**, not analytic derivatives.
They therefore sit between rows conceptually and are reported on the row they move *to*.
Row 1 of the grid has no marginal figure — correct, not missing.

The optimum is the grid row maximizing `Profit(Q)`. Because the grid is discrete, it is
accurate to within one step. Reduce step size for precision.

## Outputs

On the **Model** tab: a grid over the volume range, columns `Units`, `Price`, `Revenue`,
`Marginal Revenue`, `Total Cost`, `Marginal Cost`, `Profit`, `MR − MC`. Below it, a summary
block: optimal units, price at optimum, profit at optimum, and the resulting margin.

## Assumptions

1. **Demand is linear over the modeled range.** Defensible over a narrow band; not over a
   range wide enough to hit a new customer segment.
2. **Cost is smoothly convex.** Real capacity arrives in steps — a shift, a line, a
   facility. Where a step exists inside the range, this understates cost just before it and
   overstates just after.
3. **Single period, no carryover.** No inventory, no learning curve, no price memory in the
   customer base.
4. **Fixed cost is genuinely fixed** across the range. It does not affect the optimum —
   only whether the optimum is worth pursuing at all.

Each assumption is restated on the Assumptions tab beside the input it governs, so it is
visible to whoever opens the file rather than only to whoever read this document.

## Validation

Before shipping any run of this model:

- Confirm the optimum is interior. An optimum at the first or last grid row means the range
  is too narrow and the true answer lies outside it.
- Confirm `MR − MC` changes sign exactly once. More than one crossing means the cost or
  demand structure is not as specified.
- Confirm profit at the optimum exceeds profit at zero volume. If it does not, the
  recommendation is to not operate, and that is the finding.
